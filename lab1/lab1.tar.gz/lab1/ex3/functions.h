/*
    You can modify this file for your testing purpose but note
    that we will use our own copies of this file for testing
    during grading so any changes in this file will be overwritten
*/

int add_one(int x);
int add_two(int x);
int multiply_five(int x);
int square(int x);
int cube(int x);
