/*
    You can modify this file for your testing purpose but note
    that we will use our own copies of this file for testing
    during grading so any changes in this file will be overwritten
*/

#include "functions.h"

int add_one(int x) {
    return x + 1;
}

int add_two(int x) {
    return x + 2;
}

int multiply_five(int x) {
    return x * 5;
}

int square(int x) {
    return x * x;
}

int cube(int x) {
    return x * x * x;
}
